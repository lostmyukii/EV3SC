# Internal Test Release Evidence

Target: windows
Internal status: internal-build-ready
Internal ready: yes

## Internal Test Release

- Goal: runnable internal testing build.
- macOS signing: Internal Test Optional
- macOS notarization: Internal Test Optional
- Windows signing: Internal Test Optional
- Windows timestamp URL: Internal Test Optional

## Internal Test Required Checks

- macOS dev/unsigned build can generate: pass
- Application startup: verify with the command below.
- Core function verification: verify with the commands below.
- Build commands are reproducible: yes

## Production Release

- Goal: external/customer distribution.
- macos_developer_id: Production Release Blocker
- macos_notarization: Production Release Blocker
- windows_code_signing_certificate: Production Release Blocker
- windows_timestamp_url: Production Release Blocker
- windows_publisher_reputation: Production Release Blocker

## Build Commands

```bash
D:\a\EV3SC\EV3SC\.venv\Scripts\python.exe D:\a\EV3SC\EV3SC\desktop\scripts\build_weisilelink_executable.py --target windows --output D:\a\EV3SC\EV3SC\desktop\build\windows --clean
```

```bash
D:\a\EV3SC\EV3SC\.venv\Scripts\python.exe D:\a\EV3SC\EV3SC\desktop\scripts\build_release_artifacts.py windows --executable D:\a\EV3SC\EV3SC\desktop\build\windows\WeisileLink.exe --output D:\a\EV3SC\EV3SC\desktop\release\internal\windows --version 0.1.0-internal --allow-unsigned
```

## Verification Commands

```bash
python -m pytest tests/test_desktop_packaging.py tests/test_desktop_install_smoke.py -v
```

## Application Startup Verification

```bash
WeisileLink.exe desktop-start --check-only --config %LOCALAPPDATA%\VSLE\WeisileLink\config.json --ready-timeout 0.1
```

Expected internal-test states are `ready`, `needs_pairing`, or `needs_attention`; an unpaired test machine normally reports `needs_pairing`.

## Core Function Verification

```bash
python -m pytest tests/test_desktop_packaging.py tests/test_desktop_install_smoke.py -v
```

## Known Security Prompts

- Windows may show unknown publisher warnings.

## Notes

Unsigned Windows internal builds are for VSLE-controlled test machines only and are not production release artifacts.
