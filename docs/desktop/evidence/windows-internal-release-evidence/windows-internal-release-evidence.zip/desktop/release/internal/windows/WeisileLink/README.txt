WeisileLink Windows release artifact

Run install.ps1 from an unsigned internal smoke artifact only
when testing inside VSLE-controlled machines.
Classroom distribution requires signed installer artifacts
and clean-machine install evidence.
